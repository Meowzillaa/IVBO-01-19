package ru.mirea.lab1;
import java.util.Scanner;

public class Dog
{
    private String breed;
    private String name;
    private Integer age;
    public Dog()
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input breed: ");
        breed = in.nextLine();
        System.out.print("Input name: ");
        name = in.nextLine();
        System.out.print("Input age: ");
        age = in.nextInt();
    }
    public  String toString()
    {
        String bio;
        bio = "Breed: " + breed + "\nName: " + name + "age: " + age + "\n";
        System.out.print(bio);
        System.out.print("Age in Human rate: ");
        System.out.print(age * 7);
        return "\nEnd.";
    }
}
package ru.mirea.lab1;

public class Test
{
    public static void main(String[] a)
    {
        Dog dog = new Dog();
        System.out.print(dog);
    }
}

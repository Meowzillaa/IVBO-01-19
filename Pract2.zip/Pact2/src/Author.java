import java.util.Scanner;

public class Author
{
    private String name;
    private String email;
    private String gender;
    private String AuthorInfo;
    Scanner in = new Scanner(System.in);

    public Author()
    {

        System.out.print(getName());
        getEmail();
        setEmail(email);

        System.out.print(getGender());

        toString();

    }

    public String getName()
    {
        System.out.print("\nInput name: ");
        name = in.nextLine();
        return name;
    }

    public String getEmail()
    {
        System.out.print("\nInput email: ");
        email = in.nextLine();
        return " //// Email set.\n";
    }

    public void setEmail(String email)
    {
        System.out.print(email);
    }

    public String getGender()
    {
        System.out.print("\nInput gender: ");
        gender = in.nextLine();
        return gender;
    }

    public String toString()
    {
        return "\nEnd.";
    }

}

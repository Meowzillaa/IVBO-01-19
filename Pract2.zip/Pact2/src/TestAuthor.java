import java.util.Scanner;
public class TestAuthor
{
    public static void main(String[] a)
    {
        Author author = new Author();
        System.out.print(author);
    }

}

package ru.mirea.lab1;
import java.util.Scanner;



public class Lab1
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Scanner in = new Scanner(System.in);
        System.out.print("Введите кол-во элементов массива для первой лабораторной: ");
        Integer am = in.nextInt();;
        int[] mas; // объявление массива
        mas = new int[am];
        for(int i = 0; i < am; i++)
        {
            System.out.print("Введите " + i + "-ый элемент массива ");
            mas[i] = in.nextInt();
        }

        first(mas, am);
        for(int i = 0; i < args.length; i++)
        {
            System.out.print(args[i]);
        }
        System.out.print('\n');
        third();
        System.out.print('\n');
        fourth();
        fifth(sc);

    }

    public static void first(int[] mas, int am) // ПЕРВАЯ И ВТОРАЯ ЛАБОРАТОРНАЯ
    {
        System.out.print("\nПЕРВАЯ И ВТОРАЯ ЛАБОРАТОРНАЯ:" + '\n' + '\n');
        int res = 0, j = 0, k = 0;
        for(int i = 0; i < am; i++)
        {
            res += mas[i];
        }
        System.out.print("for: " + res + '\n');
        res = 0;
        while(j < mas.length)
        {
            res += mas[j];
            j++;
        }
        System.out.print("while: " + res + '\n');
        res = 0;
        do
            {
            res += mas[k];
            k++;
            }
        while(k < mas.length);
        System.out.print("while: " + res + '\n');
    }

    public static void second(int[] mas, int am) // ВТОРАЯ ЛАБОРАТОРНАЯ
    {
        class proverka
        {
            public void main(String[] args)
            {
                for (int i = 0; i < args.length; i++)
                    System.out.println(args[i]);
            }
        }
    }

    public static void third(){ //ТРЕТЬЯ ЛАБОРАТОРНАЯ
        System.out.print("\nТРЕТЬЯ ЛАБОРАТОРНАЯ:" + '\n' + '\n');
        float x;
        for(float i = 1; i < 11; i++)
        {
            x = 1/i;
            System.out.print(x);
            System.out.print(' ');
        }
    }
    public static void fourth() //ЧЕТВЁРТАЯ ЛАБОРАТОРНАЯ
    {
        System.out.print("\nЧЕТВЁРТАЯ ЛАБОРАТОРНАЯ:" + '\n' + '\n');
        int[] mas = new int[10];
        for(int i = 0; i < mas.length; i++)
        {
            mas[i] = (int)(Math.random()*100);
            System.out.print(mas[i]);
            System.out.print(' ');
        }
        System.out.print('\n');
        for (int i = mas.length - 1; i >= 1; i--)
        {
            for (int j = 0; j < i; j++){
                if(mas[j] > mas[j + 1]) {
                    int temp = mas[j];
                    mas[j] = mas[j + 1];
                    mas[j + 1] = temp;
                }
            }
        }
        for(int i = 0; i < mas.length; i++)
        {
            System.out.print(mas[i]);
            System.out.print(' ');
        }
    }
    public static void fifth(Scanner sc) //ПЯТАЯ ЛАБОРАТОРНАЯ
    {
        System.out.print("\nПЯТАЯ ЛАБОРАТОРНАЯ:" + '\n' + '\n');
        System.out.print('\n');
        System.out.print("Введите число для пятой лабораторной: ");
        if(sc.hasNextInt()) {
            int num = sc.nextInt(), ans = 1;
            for(int i = 1; i <= num; i++)
            {
                ans *= i;
            }
            System.out.print(ans);
        }
        else
            {
            System.out.println("Вы ввели нецелое число");
        }
    }
}
